// Shared script used by popup.html and sidebar.html
let view = 'all';
let restored = false;
// Feature toggles loaded from storage
let SHOW_RECENT = true;
let SHOW_DUPLICATES = true;
let MOVE_ENABLED = true;
let SCROLL_SPEED = 1;
let KEY_VIEW_ALL = 'Shift+A';
let KEY_VIEW_RECENT = 'Shift+R';
let KEY_VIEW_DUPS = 'Shift+D';

let lastSelectedIndex = -1;
let container; // tab list element
let scrollContainer; // scrolling element (wrapper in full view)
let dropTarget = null;
let containerMap = new Map();
let filterContainerId = '';
let containerCache;
let targetSelect;
let visitedIds = new Set();
let movePending = null;
// Persist selection across updates
let selectedIds = new Set();

// Cached tab list provided by the background script
let cachedTabs = null;

let virtualList = null;
let tabItems = [];
let idIndexMap = new Map();
let rowHeight = 0;
let currentDupIds = new Set();
let currentActiveId = -1;
let currentVisited = new Set();
let currentWinMap = null;
let currentQuery = '';
let searchOrder = null;
// Scroll position to restore after certain operations
let pendingScroll = null;
// Remember horizontal scroll for each view in full window
const fullScrollPos = { all: 0, recent: 0, dups: 0 };
// Remember vertical scroll for each view in popup window
const popupScrollPos = { all: 0, recent: 0, dups: 0 };
let easterEgg;
const collapsedWins = new Set();

// Internal pages of this extension (moz-extension://...)
const EXT_BASE = browser.runtime.getURL('');
function isInternalTab(tab) {
  return !!(tab && typeof tab.url === 'string' && tab.url.startsWith(EXT_BASE));
}

function showEasterEgg() {
  if (!easterEgg || easterEgg.classList.contains('visible')) return;
  const hide = () => {
    easterEgg.classList.remove('visible');
    setTimeout(() => easterEgg.classList.add('hidden'), 150);
    document.removeEventListener('keydown', escHandler);
  };
  const escHandler = ev => {
    if (ev.key === 'Escape') hide();
  };
  easterEgg.classList.remove('hidden');
  requestAnimationFrame(() => easterEgg.classList.add('visible'));
  easterEgg.addEventListener('click', hide, { once: true });
  document.addEventListener('keydown', escHandler);
  setTimeout(hide, 3000);
}

function matchShortcut(def, e) {
  if (!def) return false;
  const parts = def.toUpperCase().split('+');
  const key = parts.pop();
  const req = {
    CTRL: parts.includes('CTRL'),
    ALT: parts.includes('ALT'),
    META: parts.includes('META'),
    SHIFT: parts.includes('SHIFT')
  };
  return key === e.key.toUpperCase() &&
    e.ctrlKey === req.CTRL &&
    e.altKey === req.ALT &&
    e.metaKey === req.META &&
    e.shiftKey === req.SHIFT;
}

function adjustGridWidth() {
  if (!document.body.classList.contains('full')) return;
  const wrapper = document.getElementById('tabs-wrapper');
  const grid = document.getElementById('tabs');
  if (!wrapper || !grid || !grid.lastElementChild) return;
  const last = grid.lastElementChild;
  const width = Math.max(wrapper.clientWidth, last.offsetLeft + last.offsetWidth);
  grid.style.width = width + 'px';
}

function resetTabState() {
  if (virtualList) {
    virtualList.destroy();
  }
  virtualList = null;
  tabItems = [];
  idIndexMap = new Map();
  rowHeight = 0;
  currentDupIds = new Set();
  currentActiveId = -1;
  currentVisited = new Set();
  currentWinMap = null;
  currentQuery = '';
  movePending = null;
  selectedIds.clear();
}
function clearPlaceholder() {
  if (dropTarget) {
    dropTarget.classList.remove('drop-before', 'drop-after');
    dropTarget = null;
  }
}

function hideAllTooltips() {
  document.querySelectorAll('.tab-tooltip').forEach(t => t.remove());
}

function triggerViewAnimation() {
  const el = document.getElementById('tabs');
  if (!el) return;
  el.classList.remove('view-transition');
  void el.offsetWidth;
  el.classList.add('view-transition');
}

function updateViewButtons() {
  const btnAll = document.getElementById('btn-all');
  const btnRecent = document.getElementById('btn-recent');
  const btnDups = document.getElementById('btn-dups');
  btnAll?.classList.remove('active-view');
  btnRecent?.classList.remove('active-view');
  btnDups?.classList.remove('active-view');
  if (view === 'recent') btnRecent?.classList.add('active-view');
  else if (view === 'dups') btnDups?.classList.add('active-view');
  else btnAll?.classList.add('active-view');
}

function setView(newView) {
  if (document.body.classList.contains('full') && scrollContainer) {
    fullScrollPos[view] = scrollContainer.scrollLeft;
    pendingScroll = fullScrollPos[newView] || 0;
  } else if (scrollContainer) {
    popupScrollPos[view] = scrollContainer.scrollTop;
    pendingScroll = popupScrollPos[newView] || 0;
  }
  view = newView;
  updateViewButtons();
  triggerViewAnimation();
  searchOrder = null;
  scheduleUpdate();
}

function showPlaceholder(target, before) {
  if (dropTarget === target &&
      target.classList.contains(before ? 'drop-before' : 'drop-after')) {
    return;
  }
  clearPlaceholder();
  dropTarget = target;
  dropTarget.classList.add(before ? 'drop-before' : 'drop-after');
}

function throttle(fn) {
  let pending = false;
  return (...args) => {
    if (!pending) {
      pending = true;
      requestAnimationFrame(() => {
        pending = false;
        fn(...args);
      });
    }
  };
}

function debounce(fn, delay) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

function escapeHtml(str) {
  return str.replace(/[&<>"']/g, c => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[c]));
}

function truncateText(str, maxLen = 80) {
  return str.length > maxLen ? str.slice(0, maxLen - 1) + '…' : str;
}

function applyHighlights(span, indices) {
  const text = span.textContent;
  span.textContent = '';
  let last = 0;
  for (const idx of indices) {
    if (last < idx) {
      span.appendChild(document.createTextNode(text.slice(last, idx)));
    }
    const mark = document.createElement('mark');
    mark.textContent = text[idx];
    span.appendChild(mark);
    last = idx + 1;
  }
  if (last < text.length) {
    span.appendChild(document.createTextNode(text.slice(last)));
  }
}

async function loadOptions() {
  const {
    showRecent = true,
    showDuplicates = true,
    enableMove = true,
    scrollSpeed = 1,
    keyUnloadAll = 'Alt+Shift+U',
    keyViewAll = 'Shift+A',
    keyViewRecent = 'Shift+R',
    keyViewDups = 'Shift+D'
  } = await browser.storage.local.get([
    'showRecent',
    'showDuplicates',
    'enableMove',
    'scrollSpeed',
    'keyUnloadAll',
    'keyViewAll',
    'keyViewRecent',
    'keyViewDups'
  ]);
  SHOW_RECENT = showRecent !== false;
  SHOW_DUPLICATES = showDuplicates !== false;
  MOVE_ENABLED = enableMove !== false;
  SCROLL_SPEED = parseFloat(scrollSpeed) || 1;
  const btnRecent = document.getElementById('btn-recent');
  const btnDups = document.getElementById('btn-dups');
  if (btnRecent) {
    if (SHOW_RECENT) {
      btnRecent.style.display = '';
      btnRecent.addEventListener('click', () => {
        setView('recent');
      });
    } else {
      btnRecent.style.display = 'none';
      if (view === 'recent') setView('all');
    }
  }
  if (btnDups) {
    if (SHOW_DUPLICATES) {
      btnDups.style.display = '';
      btnDups.addEventListener('click', () => {
        setView('dups');
      });
    } else {
      btnDups.style.display = 'none';
      if (view === 'dups') setView('all');
    }
  }
  KEY_VIEW_ALL = keyViewAll || '';
  KEY_VIEW_RECENT = keyViewRecent || '';
  KEY_VIEW_DUPS = keyViewDups || '';
  const btnAll = document.getElementById('btn-all');
  if (btnAll) btnAll.title = KEY_VIEW_ALL ? `Shortcut: ${KEY_VIEW_ALL}` : '';
  if (btnRecent) btnRecent.title = KEY_VIEW_RECENT ? `Shortcut: ${KEY_VIEW_RECENT}` : '';
  if (btnDups) btnDups.title = KEY_VIEW_DUPS ? `Shortcut: ${KEY_VIEW_DUPS}` : '';
  const unloadBtn = document.getElementById('bulk-unload-all');
  if (unloadBtn) unloadBtn.title = `Shortcut: ${keyUnloadAll}`;
  updateViewButtons();
}

function updateSelection(row, selected) {
  if (!row.classList.contains('tab')) return;
  row.classList.toggle('selected', selected);
  if (row._item) {
    row._item.selected = selected;
    const id = row._item.tab.id;
    if (selected) {
      selectedIds.add(id);
    } else {
      selectedIds.delete(id);
    }
  } else {
    const id = parseInt(row.dataset.tab, 10);
    if (!isNaN(id)) {
      if (selected) selectedIds.add(id); else selectedIds.delete(id);
    }
  }
}

function clearSelection() {
  for (const item of tabItems) {
    if (item.separator) continue;
    item.selected = false;
    if (item.el) updateSelection(item.el, false);
  }
  selectedIds.clear();
  lastSelectedIndex = -1;
}

const saveScroll = debounce(() => {
  if (!scrollContainer) return;
  if (document.body.classList.contains('full')) {
    browser.storage.local.set({ scrollLeftFull: scrollContainer.scrollLeft });
    fullScrollPos[view] = scrollContainer.scrollTop;
  } else {
    browser.storage.local.set({ scrollTop: scrollContainer.scrollTop });
    popupScrollPos[view] = scrollContainer.scrollTop;
  }
}, 200);

function updateMenuShadow() {
  const menu = document.getElementById('menu');
  const counts = document.getElementById('counts');
  if (!menu || !scrollContainer) return;
  const scrolled =
    scrollContainer.scrollTop > 0 || scrollContainer.scrollLeft > 0;
  menu.classList.toggle('scrolled', scrolled);
  counts?.classList.toggle('scrolled', scrolled);
}

function updateFadeOverlay() {
  if (!scrollContainer) return;
  const atTop = scrollContainer.scrollTop <= 0;
  const atBottom =
    scrollContainer.scrollTop + scrollContainer.clientHeight >=
    scrollContainer.scrollHeight;
  const atLeft = scrollContainer.scrollLeft <= 0;
  const atRight =
    scrollContainer.scrollLeft + scrollContainer.clientWidth >=
    scrollContainer.scrollWidth;
  scrollContainer.classList.toggle('fade-top', !atTop);
  scrollContainer.classList.toggle('fade-bottom', !atBottom);
  scrollContainer.classList.toggle('fade-left', !atLeft);
  scrollContainer.classList.toggle('fade-right', !atRight);
}

async function restoreScroll() {
  if (restored) return;
  if (document.body.classList.contains('full')) {
    const { scrollLeftFull = 0 } = await browser.storage.local.get('scrollLeftFull');
    if (scrollContainer) {
      scrollContainer.scrollLeft = scrollLeftFull;
    }
  } else {
    const { scrollTop = 0 } = await browser.storage.local.get('scrollTop');
    if (scrollContainer) {
      scrollContainer.scrollTop = scrollTop;
    }
  }
  updateFadeOverlay();
  restored = true;
}

async function getTabs(allTabs) {
  if (view === 'recent') {
    const { recent = [] } = await browser.runtime.sendMessage({ type: 'getRecent' });
    const result = [];
    let currentWin = null;
    if (!document.body.classList.contains('full')) {
      currentWin = await browser.windows.getLastFocused({windowTypes: ['normal']});
    }
    for (const id of recent) {
      try {
        const t = await browser.tabs.get(id);
        if (isInternalTab(t)) continue;
        if (!currentWin || t.windowId === currentWin.id) {
          result.push(t);
        }
      } catch (_) {
        // tab may no longer exist
      }
    }
    return result;
  }
  if (view === 'dups') {
    return allTabs.filter(t => currentDupIds.has(t.id) && !isInternalTab(t));
  }
  return allTabs.filter(t => !isInternalTab(t));
}

function closeUI() {
  if (browser.sidebarAction) {
    try { browser.sidebarAction.close(); } catch (e) {}
  }
  window.close();
}

async function activateTab(id, winId) {
  try {
    await browser.tabs.update(id, {active: true});
    if (winId) {
      await browser.windows.update(winId, {focused: true});
    }
  } catch (e) {
    document.getElementById('error').textContent = 'Could not activate tab';
    document.querySelector(`[data-tab="${id}"]`)?.remove();
  }
}

async function getContainerIdentities() {
  if (!browser.contextualIdentities) {
    containerCache = [];
    return containerCache;
  }
  try {
    containerCache = await browser.contextualIdentities.query({});
    await browser.storage.local.set({ containerIdentities: containerCache });
  } catch (e) {
    console.error('Contextual identities unavailable', e);
    if (!containerCache) {
      const stored = await browser.storage.local.get('containerIdentities');
      containerCache = stored.containerIdentities || [];
    }
  }
  return containerCache;
}

function refreshContainerDropdowns(identities) {
  const filter = document.getElementById('container-filter');
  const target = document.getElementById('container-target');
  containerMap.clear();
  identities.forEach(ci => containerMap.set(ci.cookieStoreId, ci));
  if (filter) {
    const current = filter.value;
    filter.textContent = '';
    const optAll = document.createElement('option');
    optAll.value = '';
    optAll.textContent = 'All Containers';
    filter.appendChild(optAll);
    identities.forEach(ci => {
      const opt = document.createElement('option');
      opt.value = ci.cookieStoreId;
      opt.textContent = ci.name;
      filter.appendChild(opt);
    });
    filter.value = containerMap.has(current) ? current : '';
  }
  if (target) {
    const currentT = target.value;
    target.textContent = '';
    identities.forEach(ci => {
      const opt = document.createElement('option');
      opt.value = ci.cookieStoreId;
      opt.textContent = ci.name;
      target.appendChild(opt);
    });
    target.value = containerMap.has(currentT) ? currentT : (identities[0]?.cookieStoreId || 'firefox-default');
  }
}

function createTabRow(tab, isDuplicate, activeId, isVisited, item) {
  const row = document.createElement('div');
  const isFull = document.body.classList.contains('full');
  row.className = 'tab';
  row.dataset.tab = tab.id;
  row.dataset.windowId = tab.windowId;
  row.tabIndex = 0;
  row.draggable = true;
  row.setAttribute('draggable', 'true');
  if (item) row._item = item;
  if (tab.id === activeId || tab.active) {
    row.classList.add('active');
  }
  if (isDuplicate) {
    row.classList.add('duplicate');
  }
  if (isVisited) {
    row.classList.add('visited');
  } else if (!isVisited && !tab.discarded) {
    row.classList.add('unvisited');
  }


  const iconCell = document.createElement('div');
  if (tab.favIconUrl && !tab.favIconUrl.startsWith('chrome:')) {
    const icon = document.createElement('img');
    icon.className = 'tab-icon';
    icon.src = tab.favIconUrl;
    icon.alt = '';
    icon.onerror = () => icon.remove();
    iconCell.appendChild(icon);
  
    let tooltip;
    const showTooltip = () => {
      // Allow tooltips in both popup and full views
      hideAllTooltips();
      tooltip = document.createElement('div');
      tooltip.className = 'tab-tooltip';
      const truncatedTitle = truncateText(tab.title || tab.url);
      const truncatedUrl = truncateText(tab.url);
      const ctx = containerMap.get(tab.cookieStoreId);
      tooltip.textContent = '';
      tooltip.appendChild(document.createTextNode(truncatedTitle));
      tooltip.appendChild(document.createElement('br'));
      tooltip.appendChild(document.createTextNode(truncatedUrl));
      if (ctx) {
        tooltip.appendChild(document.createElement('br'));
        tooltip.appendChild(document.createTextNode(ctx.name));
      }
      document.body.appendChild(tooltip);
      const rect = icon.getBoundingClientRect();
      let left = rect.right + window.scrollX + 5;
      const top = rect.top + window.scrollY;
      const width = tooltip.offsetWidth;
      if (left + width > window.innerWidth - 5) {
        left = rect.left + window.scrollX - width - 5;
        tooltip.classList.add('left');
      } else {
        tooltip.classList.remove('left');
      }
      tooltip.style.left = `${left}px`;
      tooltip.style.top = `${top}px`;
      requestAnimationFrame(() => {
        if (tooltip) {
          tooltip.classList.add('visible');
        }
      });
    };
    const hideTooltip = () => {
      if (tooltip) {
        tooltip.classList.remove('visible');
        const el = tooltip;
        tooltip = null;
        setTimeout(() => {
          el.classList.remove('left');
          el.remove();
        }, 150);
      }
    };
    icon.addEventListener('mouseenter', showTooltip);
    icon.addEventListener('mouseleave', hideTooltip);
  }
  row.appendChild(iconCell);

  const indicatorCell = document.createElement('div');
  const ctx = containerMap.get(tab.cookieStoreId);
  if (ctx) {
    const indicator = document.createElement('span');
    indicator.className = 'container-indicator';
    indicator.style.backgroundColor = ctx.colorCode;
    indicator.title = ctx.name;
    indicatorCell.appendChild(indicator);
  }
  row.appendChild(indicatorCell);


  const titleCell = document.createElement('div');
  const title = document.createElement('span');
  title.textContent = tab.title || tab.url;
  title.className = 'tab-title';
  titleCell.appendChild(title);
  row.appendChild(titleCell);

  const closeCell = document.createElement('div');
  const closeBtn = document.createElement('button');
  closeBtn.className = 'close-btn';
  closeBtn.textContent = '×';
  closeBtn.title = 'Close tab';
  closeCell.appendChild(closeBtn);
  row.appendChild(closeCell);

  // ensure dragging works from any cell in popup mode
  row.querySelectorAll('*').forEach(el => {
    el.draggable = true;
    el.setAttribute('draggable', 'true');
  });

  // click and drag events handled via delegation

  return row;
}

function createWindowSeparator(label, winId, total, loaded) {
  const div = document.createElement('div');
  const collapsed = collapsedWins.has(winId);
  div.className = 'window-separator' + (collapsed ? ' collapsed' : '');
  const labelSpan = document.createElement('span');
  labelSpan.textContent = (collapsed ? '\u25B6 ' : '\u25BC ') + label.toUpperCase();
  div.appendChild(labelSpan);
  if (typeof total === 'number') {
    const badge = document.createElement('span');
    badge.className = 'count-badge';
    badge.textContent = (typeof loaded === 'number') ? `${loaded}/${total}` : String(total);
    badge.title = (typeof loaded === 'number') ? `${loaded} loaded, ${total} total` : `${total} tabs`;
    div.appendChild(badge);
  }
  div.tabIndex = -1;
  div.dataset.windowId = winId;
  return div;
}

function renderTabs(list, activeId, dupIds, visitedIds, winMap, query = '') {
  if (!container) return;
  currentDupIds = dupIds;
  currentActiveId = activeId;
  currentVisited = visitedIds;
  currentWinMap = winMap;
  currentQuery = query;
  const validIds = new Set(
    list
      .map(entry => entry.tab ?? entry)
      // In Recent view don't hide items for collapsed windows
      .filter(t => view === 'recent' || !collapsedWins.has(t.windowId))
      .map(t => t.id)
  );
  for (const id of Array.from(selectedIds)) {
    if (!validIds.has(id)) selectedIds.delete(id);
  }
  const full = document.body.classList.contains('full') && winMap;
  tabItems = [];
  idIndexMap = new Map();
  if (full && (view === 'recent' || query)) {
    const groups = new Map();
    for (const entry of list) {
      const tab = entry.tab ?? entry;
      if (!groups.has(tab.windowId)) groups.set(tab.windowId, []);
      groups.get(tab.windowId).push(entry);
    }
    // Order windows: in Recent by first occurrence in recent list; otherwise by window index
    let orderedIds;
    if (view === 'recent') {
      const seen = new Set();
      orderedIds = [];
      for (const entry of list) {
        const tab = entry.tab ?? entry;
        if (!seen.has(tab.windowId)) { seen.add(tab.windowId); orderedIds.push(tab.windowId); }
      }
    } else {
      orderedIds = Array.from(groups.keys()).sort((a, b) => (winMap.get(a) ?? 0) - (winMap.get(b) ?? 0));
    }
    for (const winId of orderedIds) {
      const entries = groups.get(winId) || [];
      const total = entries.length;
      const loaded = entries.reduce((acc, e) => acc + ((e.tab ?? e).discarded ? 0 : 1), 0);
      const idx = winMap ? winMap.get(winId) : null;
      const showHeader = view !== 'recent' || (typeof idx === 'number' && !Number.isNaN(idx));
      if (showHeader) {
        const label = `Window ${idx}`;
        tabItems.push({ separator: true, label, windowId: winId, total, loaded, el: null });
      }
      const collapsed = showHeader && collapsedWins.has(winId);
      if (collapsed) continue;
      for (const entry of entries) {
        const tab = entry.tab ?? entry;
        const item = { tab, match: entry.match, selected: selectedIds.has(tab.id), el: null };
        tabItems.push(item);
        idIndexMap.set(tab.id, tabItems.length - 1);
      }
    }
  } else {
    let lastWin = -1;
    const counts = new Map();
    const loadedCounts = new Map();
    for (const entry of list) {
      const tab = entry.tab ?? entry;
      counts.set(tab.windowId, (counts.get(tab.windowId) || 0) + 1);
      loadedCounts.set(tab.windowId, (loadedCounts.get(tab.windowId) || 0) + (tab.discarded ? 0 : 1));
    }
    for (const entry of list) {
      const tab = entry.tab ?? entry;
      if (full && tab.windowId !== lastWin) {
        tabItems.push({ separator: true, label: `Window ${winMap.get(tab.windowId)}`, windowId: tab.windowId, total: counts.get(tab.windowId) || 0, loaded: loadedCounts.get(tab.windowId) || 0, el: null });
        lastWin = tab.windowId;
      }
      if (!full || !collapsedWins.has(tab.windowId)) {
        const item = { tab, match: entry.match, selected: selectedIds.has(tab.id), el: null };
        tabItems.push(item);
        idIndexMap.set(tab.id, tabItems.length - 1);
      }
    }
  }

  container.innerHTML = '';
  if (virtualList) {
    virtualList.destroy();
    virtualList = null;
  }
  if (!tabItems.length) {
    rowHeight = 0;
    const msg = document.createElement('div');
    msg.id = 'empty';
    msg.textContent = 'No tabs to display';
    container.appendChild(msg);
    adjustGridWidth();
    return;
  }

  if (document.body.classList.contains('full')) {
    if (!rowHeight) {
      const sampleItem = tabItems.find(it => !it.separator);
      if (sampleItem) {
        const sample = createTabRow(
          sampleItem.tab,
          dupIds.has(sampleItem.tab.id),
          activeId,
          visitedIds.has(sampleItem.tab.id),
          sampleItem
        );
        sample.style.position = 'absolute';
        sample.style.visibility = 'hidden';
        container.appendChild(sample);
        rowHeight = sample.getBoundingClientRect().height || 32;
        document.documentElement.style.setProperty('--tile-height', rowHeight + 'px');
        sample.remove();
      }
    }
    for (const item of tabItems) {
      let el;
      if (item.separator) {
        el = createWindowSeparator(item.label, item.windowId, item.total, item.loaded);
      } else {
        el = createTabRow(
          item.tab,
          dupIds.has(item.tab.id),
          activeId,
          visitedIds.has(item.tab.id),
          item
        );
        if (currentQuery && item.match && item.tab.title) {
          const span = el.querySelector('.tab-title');
          if (span) {
            applyHighlights(span, item.match);
          }
        }
        if (item.selected) el.classList.add('selected');
      }
      item.el = el;
      container.appendChild(el);
    }
  } else {
    if (!virtualList) {
      const sample = createTabRow(
        tabItems[0].tab,
        dupIds.has(tabItems[0].tab.id),
        activeId,
        visitedIds.has(tabItems[0].tab.id),
        tabItems[0]
      );
      sample.style.position = 'absolute';
      sample.style.visibility = 'hidden';
      container.appendChild(sample);
      rowHeight = sample.getBoundingClientRect().height || 32;
      document.documentElement.style.setProperty('--tile-height', rowHeight + 'px');
      sample.remove();
      virtualList = HyperList.create(container, {
        height: container.clientHeight || 400,
        itemHeight: rowHeight,
        total: tabItems.length,
        generate: generateRow,
        scrollContainer,
        overrideScrollPosition: () => scrollContainer.scrollTop
      });
    } else {
      virtualList.refresh(container, {
        height: container.clientHeight || 400,
        itemHeight: rowHeight,
        total: tabItems.length,
        generate: generateRow,
        scrollContainer,
        overrideScrollPosition: () => scrollContainer.scrollTop
      });
    }
  }
  adjustGridWidth();
}

function generateRow(index) {
  const item = tabItems[index];
  if (!item) return document.createElement('div');
    if (!item.el) {
      item.el = createTabRow(item.tab, currentDupIds.has(item.tab.id), currentActiveId, currentVisited.has(item.tab.id), item);
      if (currentQuery && item.match && item.tab.title) {
        const span = item.el.querySelector('.tab-title');
        if (span) {
          applyHighlights(span, item.match);
        }
      }
      if (item.selected) item.el.classList.add('selected');
    }
  return item.el;
}

function fuzzyMatchPositions(text, query) {
  const pos = [];
  let qi = 0;
  const q = query.toLowerCase();
  const t = text.toLowerCase();
  for (let i = 0; i < t.length && qi < q.length; i++) {
    if (t[i] === q[qi]) {
      pos.push(i);
      qi++;
    }
  }
  return qi === q.length ? pos : null;
}

function fuzzyScore(pos) {
  if (!pos) return -Infinity;
  let cont = 1;
  for (let i = 1; i < pos.length; i++) {
    if (pos[i] === pos[i - 1] + 1) cont++;
  }
  return cont * 10 - pos[0];
}

function filterTabs(tabs, query) {
  const results = [];
  for (const tab of tabs) {
    const title = tab.title || '';
    const url = tab.url || '';
    const posTitle = fuzzyMatchPositions(title, query);
    const posUrl = posTitle ? null : fuzzyMatchPositions(url, query);
    if (!posTitle && !posUrl) continue;
    const score = fuzzyScore(posTitle || posUrl);
    results.push({ tab, match: posTitle, score });
  }
  results.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    return a.tab.index - b.tab.index;
  });
  return results;
}

function applySearchOrder(list) {
  if (!searchOrder || !currentQuery) return list;
  const map = new Map(list.map(it => [it.tab.id, it]));
  const ordered = [];
  for (const id of searchOrder) {
    const item = map.get(id);
    if (item) {
      ordered.push(item);
      map.delete(id);
    }
  }
  for (const item of list) {
    if (map.has(item.tab.id)) ordered.push(item);
  }
  return ordered;
}

function findDuplicates(tabs) {
  const map = new Map();
  const duplicates = [];
  for (const tab of tabs) {
    if (map.has(tab.url)) {
      duplicates.push(tab);
    } else {
      map.set(tab.url, tab);
    }
  }
  return duplicates;
}

async function update() {
  hideAllTooltips();
  const isFull = document.body.classList.contains('full');
  let prevScroll = scrollContainer
    ? isFull
      ? scrollContainer.scrollLeft
      : scrollContainer.scrollTop
    : 0;
  if (pendingScroll !== null) {
    prevScroll = pendingScroll;
    pendingScroll = null;
  }
  try {
    const allWins = document.body.classList.contains('full');
    const queryOpts = allWins ? { windowType: 'normal' } : { currentWindow: true, windowType: 'normal' };
    // Always query live tabs so counts and state update instantly
    // in both popup and full views.
    let allTabs = await browser.tabs.query(queryOpts);
    if (filterContainerId) {
      allTabs = allTabs.filter(t => t.cookieStoreId === filterContainerId);
    }
    if (allWins) {
      const wins = await browser.windows.getAll({populate: false, windowTypes: ['normal']});
      const order = new Map(wins.map((w, i) => [w.id, i]));
      allTabs.sort((a, b) => {
        const wa = order.get(a.windowId) ?? 0;
        const wb = order.get(b.windowId) ?? 0;
        return wa === wb ? a.index - b.index : wa - wb;
      });
    } else {
      allTabs.sort((a, b) => a.index - b.index);
    }
    const visibleAllTabs = allTabs.filter(t => !isInternalTab(t));
    document.getElementById('total-count').textContent = visibleAllTabs.length;
    let tabs = await getTabs(allTabs);
    let activeCount;
    if (view === 'recent') {
      activeCount = tabs.length;
    } else {
      activeCount = visibleAllTabs.filter(t => !t.discarded).length;
    }
    document.getElementById('active-count').textContent = activeCount;
    const winMap = allWins ? new Map((await browser.windows.getAll({populate: false, windowTypes: ['normal']})).map((w, i) => [w.id, i + 1])) : null;
    const dupIds = currentDupIds;
    const activeId = allTabs.find(t => t.active)?.id ?? -1;
    const searchInput = document.getElementById('search');
    const query = searchInput.value.trim();
    let list;
    if (query) {
      list = applySearchOrder(filterTabs(tabs, query));
    } else {
      list = tabs.map(t => ({ tab: t }));
    }
    renderTabs(list, activeId, dupIds, visitedIds, winMap, query);
  } catch (e) {
    console.error('Update failed', e);
    document.getElementById('error').textContent =
      'Error updating tabs: ' + (e.message || e);
  }
  if (scrollContainer) {
    if (isFull) {
      scrollContainer.scrollLeft = prevScroll;
    } else {
      scrollContainer.scrollTop = prevScroll;
    }
  }
}

const scheduleUpdate = debounce(update, 200);

browser.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === 'visitedUpdated') {
    visitedIds = new Set(msg.visited || []);
    scheduleUpdate();
  } else if (msg && msg.type === 'duplicatesUpdated') {
    currentDupIds = new Set(msg.duplicates || []);
    scheduleUpdate();
  } else if (msg && msg.type === 'tabState') {
    cachedTabs = Array.isArray(msg.tabs) ? msg.tabs : null;
    visitedIds = new Set(msg.visited || []);
    scheduleUpdate();
  }
});

const searchBox = document.getElementById('search');
const clearBtn = document.getElementById('search-clear');
const measureCtx = document.createElement('canvas').getContext('2d');

function updateClearButton() {
  if (!clearBtn) return;
  const style = window.getComputedStyle(searchBox);
  measureCtx.font = `${style.fontWeight} ${style.fontSize} ${style.fontFamily}`;
  const textWidth = measureCtx.measureText(searchBox.value).width;
  const paddingLeft = parseFloat(style.paddingLeft) || 0;
  const paddingRight = parseFloat(style.paddingRight) || 0;
  const maxLeft = searchBox.offsetWidth - clearBtn.offsetWidth - paddingRight;
  const left = Math.min(paddingLeft + textWidth + 4, maxLeft);
  clearBtn.style.left = `${left}px`;
  clearBtn.classList.toggle('hidden', !searchBox.value);
}

searchBox.addEventListener('input', () => {
  updateClearButton();
  searchOrder = null;
  scheduleUpdate();
});

window.addEventListener('resize', updateClearButton);

clearBtn?.addEventListener('click', () => {
  if (searchBox.value) {
    searchBox.value = '';
    updateClearButton();
    searchOrder = null;
    scheduleUpdate();
  }
});

updateClearButton();
document.getElementById('btn-all').addEventListener('click', () => {
  setView('all');
});

document.addEventListener('keydown', (e) => {
  if (!searchBox) return;

  if (matchShortcut(KEY_VIEW_ALL, e)) {
    setView('all');
    e.preventDefault();
    e.stopPropagation();
    return;
  }
  if (matchShortcut(KEY_VIEW_RECENT, e) && SHOW_RECENT) {
    setView('recent');
    e.preventDefault();
    e.stopPropagation();
    return;
  }
  if (matchShortcut(KEY_VIEW_DUPS, e) && SHOW_DUPLICATES) {
    setView('dups');
    e.preventDefault();
    e.stopPropagation();
    return;
  }

  if (e.key === 'Escape') {
    if (searchBox.value) {
      searchBox.value = '';
      scheduleUpdate();
    } else if (document.body.classList.contains('full')) {
      closeUI();
    }
    return;
  }

  if (document.activeElement.tagName !== 'INPUT' &&
      e.key.length === 1 &&
      !e.ctrlKey && !e.metaKey && !e.altKey &&
      !e.shiftKey) {
    searchBox.focus();
    searchBox.value += e.key;
    scheduleUpdate();
    e.preventDefault();
    e.stopPropagation();
  }
}, true);

document.addEventListener('keydown', (e) => {
  if (!tabItems.length) return;
  if (document.activeElement.tagName === 'INPUT') return;
  const focused = document.activeElement;
  const isTab = focused.classList.contains('tab');
  let idx = isTab ? idIndexMap.get(parseInt(focused.dataset.tab, 10)) : -1;

  const moveFocus = (delta) => {
    let newIdx = idx;
    do {
      newIdx = Math.min(Math.max(newIdx + delta, 0), tabItems.length - 1);
    } while (tabItems[newIdx] && tabItems[newIdx].separator);
    idx = newIdx;
    const el = tabItems[newIdx].el;
    requestAnimationFrame(() => {
      el?.focus();
      el?.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    });
    return newIdx;
  };

  if (e.key === 'Alt' && !e.ctrlKey && !e.metaKey && !e.shiftKey) {
    e.preventDefault();
    clearSelection();
    return;
  }


  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
    e.preventDefault();
    const oldIdx = idx;
    const newIdx = moveFocus(e.key === 'ArrowDown' ? 1 : -1);
    if (e.shiftKey && isTab) {
      if (lastSelectedIndex === -1) lastSelectedIndex = oldIdx;
      const start = Math.min(lastSelectedIndex, newIdx);
      const end = Math.max(lastSelectedIndex, newIdx);
      for (let i = 0; i < tabItems.length; i++) {
        if (tabItems[i].separator) continue;
        const sel = i >= start && i <= end;
        tabItems[i].selected = sel;
        if (tabItems[i].el) updateSelection(tabItems[i].el, sel);
      }
    }
    lastSelectedIndex = newIdx;
  } else if (e.key === ' ' && isTab) {
    e.preventDefault();
    const item = tabItems[idx];
    const sel = !item.selected;
    item.selected = sel;
    if (item.el) updateSelection(item.el, sel);
    lastSelectedIndex = idx;
  } else if (e.key === 'Enter' && isTab) {
    focused.click();
  } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'a') {
    e.preventDefault();
    let last = -1;
    tabItems.forEach((it, i) => {
      if (it.separator) return;
      it.selected = true;
      if (it.el) updateSelection(it.el, true);
      last = i;
    });
    lastSelectedIndex = last;
  } else if (!e.ctrlKey && !e.metaKey && !e.altKey) {
    switch (e.key.toLowerCase()) {
      case 'c':
        bulkClose();
        break;
      case 'r':
        bulkReload();
        break;
      case 'u':
        if (e.shiftKey) {
          bulkUnloadAll();
        } else {
          bulkDiscard();
        }
        break;
      case 'm':
        if (MOVE_ENABLED) bulkMove();
        break;
    }
  }
});

async function init() {
  container = document.getElementById('tabs-body') ||
              document.getElementById('tabs');
  scrollContainer = document.getElementById('tabs-wrapper') || container;
  easterEgg = document.getElementById('easter-egg');
  const menuEl = document.getElementById('menu');
  menuEl?.addEventListener('dblclick', showEasterEgg);
  scrollContainer.addEventListener('scroll', saveScroll);
  scrollContainer.addEventListener('scroll', hideAllTooltips);
  scrollContainer.addEventListener('scroll', updateMenuShadow);
  scrollContainer.addEventListener('scroll', updateFadeOverlay);
  container.addEventListener('click', onContainerClick);
  container.addEventListener('dragstart', onContainerDragStart);
  container.addEventListener('dragover', onContainerDragOver);
  container.addEventListener('drop', onContainerDrop);
  if (document.body.classList.contains('full')) {
    scrollContainer.addEventListener('wheel', (e) => {
      if (scrollContainer.scrollWidth > scrollContainer.clientWidth) {
        e.preventDefault();
        const delta = e.deltaX || e.deltaY;
        scrollContainer.scrollLeft += delta * SCROLL_SPEED;
      }
    }, { passive: false });
    document.addEventListener('wheel', (e) => {
      if (!scrollContainer || e.target.closest('#tabs-wrapper')) return;
      e.preventDefault();
      const delta = e.deltaX || e.deltaY;
      scrollContainer.scrollLeft += delta * SCROLL_SPEED;
    }, { passive: false });
  }
  document.addEventListener('contextmenu', showContextMenu);
  container.addEventListener('dragend', clearPlaceholder);
  const { visited = [] } = await browser.storage.local.get('visited');
  visitedIds = new Set(visited);
  const { duplicates = [] } = await browser.runtime.sendMessage({ type: 'getDuplicates' });
  currentDupIds = new Set(duplicates);
  await loadOptions();
  setInterval(async () => {
    try {
      const { tabs, visited: v } = await browser.runtime.sendMessage({ type: 'getTabState' });
      if (Array.isArray(tabs)) cachedTabs = tabs;
      if (Array.isArray(v)) visitedIds = new Set(v);
      scheduleUpdate();
    } catch (_) {}
  }, 5000);
  registerTabEvents();
  const select = document.getElementById('container-filter');
  let containerIdents = [];
  let containersAvailable = !!browser.contextualIdentities;
  if (browser.contextualIdentities) {
    try {
      containerIdents = await getContainerIdentities();
    } catch (e) {
      containersAvailable = false;
      console.error('Contextual identities unavailable', e);
      document.getElementById('error').textContent =
        'Container actions disabled: ' + (e.message || e);
    }
  } else {
    document.getElementById('error').textContent =
      'Container actions disabled: container feature not available';
  }
  targetSelect = document.getElementById('container-target');
  if (select || targetSelect) {
    if (containersAvailable) {
      try {
        refreshContainerDropdowns(containerIdents);
        if (select) {
          select.addEventListener('change', () => {
            filterContainerId = select.value;
            scheduleUpdate();
          });
        }
      } catch (e) {
        console.error('Contextual identities unavailable', e);
        document.getElementById('error').textContent =
          'Container actions disabled: ' + (e.message || e);
        if (select) select.disabled = true;
        if (targetSelect) targetSelect.disabled = true;
        containersAvailable = false;
        document.getElementById('container-filter')?.setAttribute('disabled', 'true');
        document.getElementById('container-target')?.setAttribute('disabled', 'true');
        document.getElementById('bulk-add-container')?.setAttribute('disabled', 'true');
        document.getElementById('bulk-remove-container')?.setAttribute('disabled', 'true');
      }
    } else {
      if (select) select.disabled = true;
      if (targetSelect) targetSelect.disabled = true;
      document.getElementById('container-filter')?.setAttribute('disabled', 'true');
      document.getElementById('container-target')?.setAttribute('disabled', 'true');
      document.getElementById('bulk-add-container')?.setAttribute('disabled', 'true');
      document.getElementById('bulk-remove-container')?.setAttribute('disabled', 'true');
    }
  }
  const bulkCloseBtn = document.getElementById('bulk-close');
  if (bulkCloseBtn) bulkCloseBtn.addEventListener('click', bulkClose);

  const bulkReloadBtn = document.getElementById('bulk-reload');
  if (bulkReloadBtn) bulkReloadBtn.addEventListener('click', bulkReload);

  const bulkDiscardBtn = document.getElementById('bulk-discard');
  if (bulkDiscardBtn) bulkDiscardBtn.addEventListener('click', bulkDiscard);

  const bulkUnloadAllBtn = document.getElementById('bulk-unload-all');
  if (bulkUnloadAllBtn) bulkUnloadAllBtn.addEventListener('click', bulkUnloadAll);

  const bulkClearBtn = document.getElementById('bulk-clear');
  if (bulkClearBtn) bulkClearBtn.addEventListener('click', clearSelection);

  const addContainerBtn = document.getElementById('bulk-add-container');
  if (addContainerBtn) {
    if (containersAvailable) {
      addContainerBtn.addEventListener('click', () => {
        const id = targetSelect ? targetSelect.value : 'firefox-default';
        bulkAssignToContainer(id);
      });
    } else {
      addContainerBtn.disabled = true;
    }
  }

  const removeContainerBtn = document.getElementById('bulk-remove-container');
  if (removeContainerBtn) {
    if (containersAvailable) {
      removeContainerBtn.addEventListener('click', bulkRemoveFromContainer);
    } else {
      removeContainerBtn.disabled = true;
    }
  }

  const moveBtn = document.getElementById('bulk-move');
  if (MOVE_ENABLED && moveBtn) moveBtn.addEventListener('click', bulkMove);
  else if (moveBtn) moveBtn.style.display = 'none';
  await update();
  restoreScroll();
  updateMenuShadow();
  updateFadeOverlay();
}

// keep the tab list current while the popup is open
const updateListener = () => scheduleUpdate();
function registerTabEvents() {
  browser.tabs.onCreated.addListener(updateListener);
  browser.tabs.onRemoved.addListener(updateListener);
  browser.tabs.onUpdated.addListener(updateListener);
  browser.tabs.onActivated.addListener(updateListener);
  browser.tabs.onDetached.addListener(updateListener);
  browser.tabs.onAttached.addListener(updateListener);
}

function unregisterTabEvents() {
  browser.tabs.onCreated.removeListener(updateListener);
  browser.tabs.onRemoved.removeListener(updateListener);
  browser.tabs.onUpdated.removeListener(updateListener);
  browser.tabs.onActivated.removeListener(updateListener);
  browser.tabs.onDetached.removeListener(updateListener);
  browser.tabs.onAttached.removeListener(updateListener);
}

function cleanup() {
  unregisterTabEvents();
  resetTabState();
}

document.addEventListener('DOMContentLoaded', init);
if (document.readyState !== 'loading') {
  init();
}
window.addEventListener('unload', cleanup);

// recompute item height when theme or scaling changes
window.addEventListener('theme-applied', () => {
  rowHeight = 0;
  scheduleUpdate();
});

browser.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if ('keyViewAll' in changes) {
    KEY_VIEW_ALL = changes.keyViewAll.newValue || '';
    document.getElementById('btn-all').title = KEY_VIEW_ALL ? `Shortcut: ${KEY_VIEW_ALL}` : '';
  }
  if ('keyViewRecent' in changes) {
    KEY_VIEW_RECENT = changes.keyViewRecent.newValue || '';
    const btn = document.getElementById('btn-recent');
    if (btn) btn.title = KEY_VIEW_RECENT ? `Shortcut: ${KEY_VIEW_RECENT}` : '';
  }
  if ('keyViewDups' in changes) {
    KEY_VIEW_DUPS = changes.keyViewDups.newValue || '';
    const btn = document.getElementById('btn-dups');
    if (btn) btn.title = KEY_VIEW_DUPS ? `Shortcut: ${KEY_VIEW_DUPS}` : '';
  }
});

window.addEventListener('resize', () => {
  if (document.body.classList.contains('full')) {
    requestAnimationFrame(adjustGridWidth);
  }
});

// custom context menu
const context = document.getElementById('context');
async function movePendingTo(targetEl, evt) {
  const ids = movePending;
  if (!ids || !ids.length) return;
  const toId = parseInt(targetEl.dataset.tab, 10);
  const toTab = await browser.tabs.get(toId);
  const rect = targetEl.getBoundingClientRect();
  const before = evt.clientY < rect.top + rect.height / 2;
  let index = before ? toTab.index : toTab.index + 1;
  for (const id of ids) {
    if (id === toId) continue;
    const fromTab = await browser.tabs.get(id);
    let idx = index;
    if (fromTab.windowId === toTab.windowId && fromTab.index < index) {
      idx--;
    }
    if (idx < 0) idx = 0;
    await browser.tabs.move(id, { windowId: toTab.windowId, index: idx });
    if (fromTab.windowId !== toTab.windowId || fromTab.index >= index) {
      index++;
    }
  }
  if (view === 'recent') {
    await browser.runtime.sendMessage({
      type: 'reorderRecent',
      ids,
      toId,
      before
    }).catch(() => {});
  }
  movePending = null;
  tabItems.forEach(it => it.el?.classList.remove('move-pending'));
  scheduleUpdate();
}

function flagTabsForMove() {
  movePending = getSelectedTabIds().slice();
  tabItems.forEach(it => {
    if (!it.separator && it.selected && it.el) {
      it.el.classList.add('move-pending');
    }
  });
}

function clearMovePending() {
  movePending = null;
  tabItems.forEach(it => it.el?.classList.remove('move-pending'));
}


function showContextMenu(e) {
  const inTabs = e.target.closest('#tabs');
  const inMenu = e.target.closest('#context');

  if (!inTabs) {
    e.preventDefault();
    hideContextMenu();
    if (inMenu) showEasterEgg();
    return;
  }

  e.preventDefault();
  hideAllTooltips();
  const tabEl = e.target.closest('.tab');
  context.innerHTML = '';

  const selected = getSelectedTabIds();
  const addItem = (label, fn) => {
    const item = document.createElement('div');
    item.textContent = label;
    item.addEventListener('click', async () => {
      hideContextMenu();
      await fn();
    });
    context.appendChild(item);
  };

  if (selected.length) {
    addItem('Close Selected', bulkClose);
    addItem('Reload Selected', bulkReload);
    if (document.body.classList.contains('full')) {
      addItem('Activate Selected', bulkActivate);
    }
    addItem('Unload Selected', bulkDiscard);
    if (MOVE_ENABLED) {
      if (!movePending) addItem('Flag for Move', flagTabsForMove);
      else addItem('Clear Move Flag', clearMovePending);
    }
    addItem('Add Selected to Container', () => {
      const id = targetSelect ? targetSelect.value : 'firefox-default';
      return bulkAssignToContainer(id);
    });
    addItem('Remove Selected from Container', bulkRemoveFromContainer);
  }

  if (MOVE_ENABLED && movePending && tabEl) {
    addItem('Move Flagged Tabs Here', () => movePendingTo(tabEl, e));
  }

  if (tabEl && (!selected.length || !tabEl.classList.contains('selected'))) {
    const id = parseInt(tabEl.dataset.tab, 10);
    const win = parseInt(tabEl.dataset.windowId, 10);
    // Place Close as the first entry for single-tab actions
    addItem('Close', async () => {
      if (scrollContainer) {
        const isFull = document.body.classList.contains('full');
        pendingScroll = isFull
          ? scrollContainer.scrollLeft
          : scrollContainer.scrollTop;
      }
      await browser.tabs.remove(id);
      scheduleUpdate();
    });
    addItem('Activate', () => activateTab(id, win));
    addItem('Unload', async () => {
      try {
        await browser.tabs.discard(id);
        await browser.runtime.sendMessage({ type: 'unmarkVisited', tabId: id });
      } catch (_) {}
      scheduleUpdate();
    });
    // Direct move option removed in favor of flagged move workflow
  }

  if (!tabEl && !selected.length) {
    return;
  }

  addItem('Unload All Tabs', bulkUnloadAll);
  if (!document.body.classList.contains('full')) {
    addItem('Open Full View', () => browser.runtime.sendMessage({ type: 'openFullView' }));
  }
  addItem('Options', () => browser.runtime.openOptionsPage());

  context.style.left = e.pageX + 'px';
  context.style.top = e.pageY + 'px';
  context.classList.remove('hidden');
  const rect = context.getBoundingClientRect();
  const vw = document.documentElement.clientWidth;
  const vh = document.documentElement.clientHeight;
  let left = e.pageX;
  let top = e.pageY;
  if (left + rect.width > vw) {
    left = Math.max(0, vw - rect.width - 5);
  }
  if (top + rect.height > vh) {
    top = Math.max(0, vh - rect.height - 5);
  }
  context.style.left = left + 'px';
  context.style.top = top + 'px';
  requestAnimationFrame(() => context.classList.add('visible'));
}

function hideContextMenu() {
  if (context.classList.contains('hidden')) return;
  context.classList.remove('visible');
  setTimeout(() => context.classList.add('hidden'), 150);
}

document.addEventListener('click', hideContextMenu);

function getSelectedTabIds() {
  return tabItems.filter(it => !it.separator && it.selected).map(it => it.tab.id);
}

async function bulkClose() {
  const ids = getSelectedTabIds();
  if (ids.length) await browser.tabs.remove(ids);
  scheduleUpdate();
}

async function bulkReload() {
  const ids = getSelectedTabIds();
  await Promise.all(ids.map(id => browser.tabs.reload(id)));
}

async function bulkActivate() {
  const tabs = await Promise.all(
    getSelectedTabIds().map(id => browser.tabs.get(id))
  );
  for (const tab of tabs) {
    await activateTab(tab.id, tab.windowId);
  }
}

async function bulkDiscard() {
  const ids = getSelectedTabIds();
  await Promise.all(ids.map(async id => {
    try {
      await browser.tabs.discard(id);
      await browser.runtime.sendMessage({ type: 'unmarkVisited', tabId: id });
    } catch (_) {}
  }));
  scheduleUpdate();
}

async function bulkUnloadAll() {
  const tabs = await browser.tabs.query({});
  await Promise.all(tabs.map(async t => {
    try {
      await browser.tabs.discard(t.id);
    } catch (_) {}
  }));
  await browser.runtime.sendMessage({ type: 'clearVisitHistory' });
  scheduleUpdate();
}

async function bulkMove() {
  const ids = getSelectedTabIds();
  const windows = await browser.windows.getAll({populate: false, windowTypes: ['normal']});
  const currentWinId = ids.length ? (await browser.tabs.get(ids[0])).windowId : null;
  const other = windows.find(w => ids.length && w.id !== currentWinId);
  if (other) {
    const tabs = await Promise.all(ids.map(id => browser.tabs.get(id)));
    tabs.sort((a, b) => a.index - b.index);
    for (const tab of tabs) {
      await browser.tabs.move(tab.id, { windowId: other.id, index: -1 });
    }
  }
  scheduleUpdate();
}

async function bulkAssignToContainer(containerId) {
  const errorEl = document.getElementById('error');
  if (errorEl) errorEl.textContent = '';
  let identities = [];
  if (browser.contextualIdentities) {
    try {
      identities = await getContainerIdentities();
      refreshContainerDropdowns(identities);
      if (containerId !== 'firefox-default') {
        const exists = identities.some(ci => ci.cookieStoreId === containerId);
        if (!exists) {
          if (errorEl) errorEl.textContent = 'Selected container does not exist';
          return;
        }
      }
    } catch (e) {
      console.error('Contextual identities unavailable', e);
      if (errorEl) {
        errorEl.textContent = 'Container actions disabled: ' + (e.message || e);
      }
      return;
    }
  }
  const ids = getSelectedTabIds();
  if (!ids.length) return;
  if (ids.length > 10 && !confirm(`Move ${ids.length} tabs to the selected container?`)) return;
  let tabs = await Promise.all(ids.map(id => browser.tabs.get(id)));
  tabs.sort((a, b) => a.windowId === b.windowId ? a.index - b.index : a.windowId - b.windowId);
  const failed = [];
  const idMap = [];
  for (const tab of tabs) {
    try {
      if (/^(about:|moz-extension:|chrome:|file:|view-source:)/.test(tab.url)) {
        failed.push(tab.title || tab.url);
        continue;
      }
      const newTab = await browser.tabs.create({
        url: tab.url,
        cookieStoreId: containerId,
        index: tab.index,
        windowId: tab.windowId,
        pinned: tab.pinned,
        active: tab.active
      });
      try {
        await browser.tabs.remove(tab.id);
        if (newTab && newTab.id) {
          idMap.push([tab.id, newTab.id]);
        }
      } catch (e) {
        console.error('Failed to remove tab', e);
        failed.push(tab.title || tab.url);
        if (newTab && newTab.id) {
          await browser.tabs.remove(newTab.id);
        }
      }
    } catch (e) {
      console.error('Failed to move tab', e);
      failed.push(tab.title || tab.url);
    }
  }
  for (const [oldId, newId] of idMap) {
    selectedIds.delete(oldId);
    selectedIds.add(newId);
    if (searchOrder) {
      const idx = searchOrder.indexOf(oldId);
      if (idx !== -1) searchOrder[idx] = newId;
    }
  }
  scheduleUpdate();
  if (failed.length) {
    if (errorEl) errorEl.textContent = `Some tabs could not be moved: ${failed.join(', ')}`;
  }
}

async function bulkRemoveFromContainer() {
  await bulkAssignToContainer('firefox-default');
}

function onContainerClick(e) {
  hideAllTooltips();
  const sepEl = e.target.closest('.window-separator');
  if (sepEl && container.contains(sepEl)) {
    const winId = parseInt(sepEl.dataset.windowId, 10);
    if (collapsedWins.has(winId)) collapsedWins.delete(winId);
    else collapsedWins.add(winId);
    scheduleUpdate();
    return;
  }
  const tabEl = e.target.closest('.tab');
  if (!tabEl || !container.contains(tabEl)) return;
  if (e.target.classList.contains('close-btn')) {
    e.stopPropagation();
    const id = parseInt(tabEl.dataset.tab, 10);
    if (scrollContainer) {
      const isFull = document.body.classList.contains('full');
      pendingScroll = isFull
        ? scrollContainer.scrollLeft
        : scrollContainer.scrollTop;
    }
    browser.tabs.remove(id).then(scheduleUpdate);
    return;
  }
  const tabs = Array.from(document.querySelectorAll('.tab'));
  const idx = tabs.indexOf(tabEl);
  if (e.ctrlKey || e.metaKey || e.shiftKey) {
    e.preventDefault();
    if (e.shiftKey && lastSelectedIndex !== -1) {
      const start = Math.min(lastSelectedIndex, idx);
      const end = Math.max(lastSelectedIndex, idx);
      const select = !tabEl.classList.contains('selected');
      for (let i = start; i <= end; i++) {
        updateSelection(tabs[i], select);
      }
    } else {
      updateSelection(tabEl, !tabEl.classList.contains('selected'));
    }
    lastSelectedIndex = idx;
    return;
  }
  activateTab(
    parseInt(tabEl.dataset.tab, 10),
    parseInt(tabEl.dataset.windowId, 10)
  );
}

function onContainerDragStart(e) {
  hideAllTooltips();
  const tabEl = e.target.closest('.tab');
  if (!tabEl) return;
  const selected = getSelectedTabIds();
  if (selected.length > 1 && tabEl.classList.contains('selected')) {
    e.dataTransfer.setData('text/plain', selected.join(','));
  } else {
    e.dataTransfer.setData('text/plain', tabEl.dataset.tab);
  }
  e.dataTransfer.effectAllowed = 'move';
  clearPlaceholder();
}

function onContainerDragOver(e) {
  hideAllTooltips();
  const tabEl = e.target.closest('.tab');
  if (!tabEl) return;
  e.preventDefault();
  e.dataTransfer.dropEffect = 'move';
  const rect = tabEl.getBoundingClientRect();
  const before = e.clientY < rect.top + rect.height / 2;
  showPlaceholder(tabEl, before);
}

async function onContainerDrop(e) {
  hideAllTooltips();
  const tabEl = e.target.closest('.tab');
  if (!tabEl) return;
  e.preventDefault();
  clearPlaceholder();
  const data = e.dataTransfer.getData('text/plain');
  const ids = data.split(',').map(id => parseInt(id, 10)).filter(n => !isNaN(n));
  const toId = parseInt(tabEl.dataset.tab, 10);
  if (!ids.length) return;
  const toTab = await browser.tabs.get(toId);
  const rect = tabEl.getBoundingClientRect();
  const before = e.clientY < rect.top + rect.height / 2;
  let index = before ? toTab.index : toTab.index + 1;
  for (const id of ids) {
    if (id === toId) continue;
    const fromTab = await browser.tabs.get(id);
    let idx = index;
    if (fromTab.windowId === toTab.windowId && fromTab.index < index) {
      idx--;
    }
    if (idx < 0) idx = 0;
    await browser.tabs.move(id, { windowId: toTab.windowId, index: idx });
    if (fromTab.windowId !== toTab.windowId || fromTab.index >= index) {
      index++;
    }
  }
  if (view === 'recent') {
    await browser.runtime.sendMessage({
      type: 'reorderRecent',
      ids,
      toId,
      before
    }).catch(() => {});
  }
  if (currentQuery) {
    if (!searchOrder) {
      searchOrder = tabItems.filter(it => !it.separator).map(it => it.tab.id);
    }
    let pos = searchOrder.indexOf(toId);
    if (!before) pos++;
    for (const id of ids) {
      const idx = searchOrder.indexOf(id);
      if (idx >= 0) {
        searchOrder.splice(idx, 1);
        if (idx < pos) pos--;
      }
    }
    searchOrder.splice(pos, 0, ...ids);
  }
  scheduleUpdate();
}

